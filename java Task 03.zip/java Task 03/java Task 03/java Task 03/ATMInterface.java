import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = Math.max(initialBalance, 0.0);
    }

    public void deposit(double amount) {
        if (amount > 0.0) {
            balance += amount;
            JOptionPane.showMessageDialog(null, "Successfully deposited $" + amount);
        } else {
            JOptionPane.showMessageDialog(null, "Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0.0 && amount <= balance) {
            balance -= amount;
            JOptionPane.showMessageDialog(null, "Successfully withdrew $" + amount);
        } else if (amount > balance) {
            JOptionPane.showMessageDialog(null, "Insufficient balance for withdrawal.");
        } else {
            JOptionPane.showMessageDialog(null, "Withdrawal amount must be positive.");
        }
    }

    public double checkBalance() {
        return balance;
    }
}

public class ATMInterface extends JFrame {
    private BankAccount account;
    private JTextField amountField;
    private JLabel messageLabel;

    public ATMInterface(BankAccount account) {
        this.account = account;
        setTitle("ATM");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel imagePanel = new JPanel() {
            private BufferedImage image;
            {
                try {
                    image = ImageIO.read(new File("atm.jpg"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (image != null) {
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                }
            }
        };

        imagePanel.setPreferredSize(new Dimension(400, 100));
        add(imagePanel, BorderLayout.NORTH);

        JLabel welcomeLabel = new JLabel("Welcome to the ATM!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setOpaque(true);
        welcomeLabel.setBackground(Color.BLACK);

        JLabel amountLabel = new JLabel("Amount ($):");
        amountField = new JTextField(10);

        JButton depositButton = new JButton("Deposit");
        JButton withdrawButton = new JButton("Withdraw");
        JButton checkBalanceButton = new JButton("Check Balance");

        messageLabel = new JLabel("Please Select an Action.", SwingConstants.CENTER);
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setOpaque(true);
        messageLabel.setBackground(Color.BLUE);

        depositButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performDeposit();
            }
        });

        withdrawButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performWithdraw();
            }
        });

        checkBalanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performCheckBalance();
            }
        });

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        centerPanel.add(amountLabel, gbc);

        gbc.gridx = 1;
        centerPanel.add(amountField, gbc);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(depositButton);
        buttonPanel.add(withdrawButton);
        buttonPanel.add(checkBalanceButton);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        centerPanel.add(buttonPanel, gbc);

        add(centerPanel, BorderLayout.CENTER);
        add(messageLabel, BorderLayout.SOUTH);
    }

    private void performDeposit() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            account.deposit(amount);
            messageLabel.setText("Deposited $" + amount + ". New Balance: $" + account.checkBalance());
            amountField.setText("");
        } catch (NumberFormatException ex) {
            messageLabel.setText("Invalid input. Please enter a valid amount.");
        }
    }

    private void performWithdraw() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            account.withdraw(amount);
            messageLabel.setText("Withdrew $" + amount + ". New Balance: $" + account.checkBalance());
            amountField.setText("");
        } catch (NumberFormatException ex) {
            messageLabel.setText("Invalid input. Please enter a valid amount.");
        }
    }

    private void performCheckBalance() {
        messageLabel.setText("Current Balance: $" + account.checkBalance());
        amountField.setText("");
    }

    public static void main(String[] args) {
        BankAccount userAccount = new BankAccount(500.0);
        ATMInterface atmInterface = new ATMInterface(userAccount);
        atmInterface.setVisible(true);
    }
}

