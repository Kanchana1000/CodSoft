import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

class Student {
    private String name;
    private int rollNumber;
    private String grade;

    public Student(String name, int rollNumber, String grade) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.grade = grade;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Roll No: " + rollNumber + ", Name: " + name + ", Grade: " + grade;
    }
}

class StudentManagementSystem {
    private ArrayList<Student> students;

    public StudentManagementSystem() {
        students = new ArrayList<>();
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void removeStudent(Student student) {
        students.remove(student);
    }

    public ArrayList<Student> getAllStudents() {
        return students;
    }
}


public class StudentManagementGUI extends JFrame {
    private StudentManagementSystem system;
    private JTextField nameField, rollField, gradeField;
    private JList<Student> studentList;
    private DefaultListModel<Student> listModel;
    private JButton editButton, saveButton;

    public StudentManagementGUI() {
        system = new StudentManagementSystem();
        listModel = new DefaultListModel<>();

        setTitle("Student Management System");
        setSize(800, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        
        setLayout(new BorderLayout());

        
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(210, 240, 255)); 
        add(mainPanel, BorderLayout.CENTER);

        
        JLabel titleLabel = new JLabel("Manage Students", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 51, 102)); 
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        inputPanel.setOpaque(false); 

        
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        nameLabel.setForeground(Color.BLACK);
        inputPanel.add(nameLabel);

        nameField = new JTextField();
        inputPanel.add(nameField);

        JLabel rollLabel = new JLabel("Roll No:");
        rollLabel.setFont(new Font("Arial", Font.BOLD, 14));
        rollLabel.setForeground(Color.BLACK);
        inputPanel.add(rollLabel);

        rollField = new JTextField();
        inputPanel.add(rollField);

        JLabel gradeLabel = new JLabel("Grade:");
        gradeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gradeLabel.setForeground(Color.BLACK);
        inputPanel.add(gradeLabel);

        gradeField = new JTextField();
        inputPanel.add(gradeField);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false); 

        JButton addButton = new JButton("Add Student");
        addButton.setBackground(new Color(0, 204, 102)); 
        addButton.setForeground(Color.WHITE);
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        buttonPanel.add(addButton);

        editButton = new JButton("Edit Student");
        editButton.setBackground(new Color(0, 204, 204)); 
        editButton.setForeground(Color.WHITE);
        editButton.setFont(new Font("Arial", Font.BOLD, 14));
        buttonPanel.add(editButton);

    
        saveButton = new JButton("Save Changes");
        saveButton.setBackground(new Color(255, 153, 51)); 
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 14));
        saveButton.setVisible(false); 
        buttonPanel.add(saveButton);

        
        JButton removeButton = new JButton("Remove Student");
        removeButton.setBackground(new Color(255, 77, 77)); 
        removeButton.setForeground(Color.WHITE);
        removeButton.setFont(new Font("Arial", Font.BOLD, 14));
        buttonPanel.add(removeButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        
        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBorder(BorderFactory.createTitledBorder("Added Students"));
        listPanel.setBackground(new Color(230, 255, 250)); 
        studentList = new JList<>(listModel);
        studentList.setFont(new Font("Arial", Font.PLAIN, 14));
        studentList.setBackground(new Color(245, 245, 245)); 
        JScrollPane listScrollPane = new JScrollPane(studentList);
        listScrollPane.setPreferredSize(new Dimension(400, 200));
        listPanel.add(listScrollPane, BorderLayout.CENTER);
        mainPanel.add(listPanel, BorderLayout.EAST);

        
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                int rollNumber;
                try {
                    rollNumber = Integer.parseInt(rollField.getText());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid Roll No. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                String grade = gradeField.getText();

                Student student = new Student(name, rollNumber, grade);
                system.addStudent(student);
                listModel.addElement(student); 
                clearInputFields();
            }
        });

        
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Student selectedStudent = studentList.getSelectedValue();
                if (selectedStudent != null) {
                    nameField.setText(selectedStudent.getName());
                    rollField.setText(String.valueOf(selectedStudent.getRollNumber()));
                    gradeField.setText(selectedStudent.getGrade());
                    saveButton.setVisible(true); 
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a student to edit.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Student selectedStudent = studentList.getSelectedValue();
                if (selectedStudent != null) {
                    String updatedName = nameField.getText();
                    int updatedRollNumber;
                    try {
                        updatedRollNumber = Integer.parseInt(rollField.getText());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid Roll No. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    String updatedGrade = gradeField.getText();

                    selectedStudent.setName(updatedName);
                    selectedStudent.setRollNumber(updatedRollNumber);
                    selectedStudent.setGrade(updatedGrade);
                    studentList.repaint(); 
                    saveButton.setVisible(false); 
                    clearInputFields();
                }
            }
        });

        
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Student selectedStudent = studentList.getSelectedValue();
                if (selectedStudent != null) {
                    system.removeStudent(selectedStudent); 
                    listModel.removeElement(selectedStudent); 
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a student to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }


    private void clearInputFields() {
        nameField.setText("");
        rollField.setText("");
        gradeField.setText("");
    }

    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentManagementGUI().setVisible(true);
        });
    }
}








