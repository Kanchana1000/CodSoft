import java.util.Scanner;

public class StudentGradeCalculator {

    private int numSubjects;
    private int[] marks;

    public StudentGradeCalculator(int numSubjects) {
        this.numSubjects = numSubjects;
        marks = new int[numSubjects];
    }

    // Method to input marks
    public void inputMarks() {
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < numSubjects; i++) {
            System.out.print("Enter marks for subject " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }
    }

    // Method to calculate total, average, and grade
    public void calculateGrade() {
        int totalMarks = 0;
        for (int i = 0; i < numSubjects; i++) {
            totalMarks += marks[i];
        }

        double averagePercentage = (double) totalMarks / numSubjects;
        char grade;

        if (averagePercentage >= 90) {
            grade = 'A';
        } else if (averagePercentage >= 80) {
            grade = 'B';
        } else if (averagePercentage >= 70) {
            grade = 'C';
        } else if (averagePercentage >= 60) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        // Display results
        System.out.println("Total Marks: " + totalMarks);
        System.out.printf("Average Percentage: %.2f%%\n", averagePercentage);
        System.out.println("Grade: " + grade);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of subjects: ");
        int numSubjects = scanner.nextInt();

        StudentGradeCalculator calculator = new StudentGradeCalculator(numSubjects);
        calculator.inputMarks();
        calculator.calculateGrade();
    }
}

