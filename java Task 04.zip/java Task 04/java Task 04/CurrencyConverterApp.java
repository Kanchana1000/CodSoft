import java.util.Scanner;

class CurrencyConverter {
    private static final double USD_TO_EUR = 0.85;
    private static final double USD_TO_GBP = 0.75;
    private static final double EUR_TO_USD = 1.18;
    private static final double EUR_TO_GBP = 0.88;
    private static final double GBP_TO_USD = 1.33;
    private static final double GBP_TO_EUR = 1.14;

    public double convert(String fromCurrency, String toCurrency, double amount) {
        double rate = 1.0;

        if (fromCurrency.equals("USD")) {
            if (toCurrency.equals("EUR")) {
                rate = USD_TO_EUR;
            } else if (toCurrency.equals("GBP")) {
                rate = USD_TO_GBP;
            }
        } else if (fromCurrency.equals("EUR")) {
            if (toCurrency.equals("USD")) {
                rate = EUR_TO_USD;
            } else if (toCurrency.equals("GBP")) {
                rate = EUR_TO_GBP;
            }
        } else if (fromCurrency.equals("GBP")) {
            if (toCurrency.equals("USD")) {
                rate = GBP_TO_USD;
            } else if (toCurrency.equals("EUR")) {
                rate = GBP_TO_EUR;
            }
        }

        return amount * rate; 
    }

    
    public boolean isValidCurrency(String currency) {
        return currency.equals("USD") || currency.equals("EUR") || currency.equals("GBP");
    }
}

public class CurrencyConverterApp {
    private static Scanner scanner = new Scanner(System.in);
    private static CurrencyConverter converter = new CurrencyConverter();

    public static void main(String[] args) {
        boolean continueConversion = true;

        while (continueConversion) {
            performConversion();
            continueConversion = askToContinue();
        }

        System.out.println("Thank you for using the Currency Converter. Goodbye!");
    }

    private static void performConversion() {
        String baseCurrency;
        String targetCurrency;
        double amount;

        while (true) {
            System.out.print("Enter the base currency (USD, EUR, GBP): ");
            baseCurrency = scanner.next().toUpperCase();

            if (converter.isValidCurrency(baseCurrency)) {
                break;
            } else {
                System.out.println("Invalid base currency. Please enter USD, EUR, or GBP.");
            }
        }

        while (true) {
            System.out.print("Enter the target currency (USD, EUR, GBP): ");
            targetCurrency = scanner.next().toUpperCase();

            if (converter.isValidCurrency(targetCurrency)) {
                break;
            } else {
                System.out.println("Invalid target currency. Please enter USD, EUR, or GBP.");
            }
        }

        while (true) {
            System.out.print("Enter the amount: ");
            try {
                amount = Double.parseDouble(scanner.next());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid amount. Please enter a valid number.");
            }
        }

        double convertedAmount = converter.convert(baseCurrency, targetCurrency, amount);
        System.out.printf("Converted Amount: %.2f %s%n", convertedAmount, targetCurrency);
    }

    private static boolean askToContinue() {
        while (true) {
            System.out.print("Do you want to perform another conversion? (Yes/No): ");
            String response = scanner.next().toLowerCase();

            if (response.equals("yes")) {
                return true;
            } else if (response.equals("no")) {
                return false;
            } else {
                System.out.println("Invalid input. Please enter 'Yes' or 'No'.");
            }
        }
    }
}




